"""
YuvalIntern Week 1 - Data Acquisition, Cleaning and Preprocessing
Tanu Singh
Dataset: Mauna Loa Weekly Atmospheric CO2 Data
Source: statsmodels public dataset (original source: Keeling & Whorf / CDIAC)
"""

import pandas as pd
import statsmodels.api as sm

# 1. Acquire public dataset
df = sm.datasets.co2.load_pandas().data.copy()
df.index.name = "date"
df = df.reset_index()

# 2. Parse and sort dates
df["date"] = pd.to_datetime(df["date"])
df = df.sort_values("date").reset_index(drop=True)

# 3. Initial audit
print("Shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nDuplicate dates:", df["date"].duplicated().sum())
print("\nSummary statistics:\n", df["co2"].describe())

# 4. Missing-value handling
df["co2"] = df["co2"].interpolate(method="linear", limit_direction="both")

# 5. IQR outlier detection
q1 = df["co2"].quantile(0.25)
q3 = df["co2"].quantile(0.75)
iqr = q3 - q1
lower = q1 - 1.5 * iqr
upper = q3 + 1.5 * iqr
outliers = df[(df["co2"] < lower) | (df["co2"] > upper)]
print("IQR outliers:", len(outliers))

# 6. Save cleaned data
df.to_csv("data/co2_cleaned.csv", index=False)
print("Saved: data/co2_cleaned.csv")
