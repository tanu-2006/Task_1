# YuvalIntern Week 1 - Data Acquisition, Cleaning and Preprocessing

**Student:** Tanu Singh  
**Internship:** Virtual Data Science with Python Trainee  
**Task:** Week 1 - Data Acquisition, Cleaning, and Preprocessing

## Dataset
Mauna Loa Weekly Atmospheric CO2 Data, provided through the `statsmodels` public datasets package.
Period: March 1958 to December 2001.

Official documentation:
https://www.statsmodels.org/0.9.0/datasets/generated/co2.html

## What was done
1. Acquired the public dataset using `statsmodels.api`.
2. Parsed and sorted the date field.
3. Checked dataset shape, data types, missing values and duplicate dates.
4. Handled 59 missing CO2 observations using linear interpolation.
5. Performed an IQR-based outlier check; 0 observations were flagged.
6. Exported the cleaned dataset to `data/co2_cleaned.csv`.
7. Generated charts documenting the preprocessing work.

## Results
- Raw rows: 2284
- Missing CO2 values before cleaning: 59
- Missing CO2 values after cleaning: 0
- Duplicate dates: 0
- IQR outliers: 0
